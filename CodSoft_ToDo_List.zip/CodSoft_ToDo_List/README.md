# TaskFlow — To-Do List Application

**CodSoft Python Programming Internship — Task 1**

A beginner-friendly To-Do List desktop application made with Python and Tkinter. It helps users create, update, search, filter, complete, and delete tasks. Tasks are saved in a local JSON file, so they remain available after closing the application.

## Features
- Add tasks with a priority (Low, Medium, High)
- Optional due date (`YYYY-MM-DD`)
- Edit a selected task
- Mark tasks as completed or pending
- Delete tasks with a confirmation prompt
- Search tasks by name
- Filter all, pending, or completed tasks
- Summary cards showing total, completed, and pending tasks
- Automatic saving to `tasks.json`

## Requirements
- Python 3.9 or later
- Tkinter (included with most standard Python installations)

No third-party packages are required.

## How to run on Windows
1. Extract the ZIP file.
2. Open the extracted `CodSoft_ToDo_List` folder.
3. Open PowerShell or the VS Code terminal in that folder.
4. Run:

   ```powershell
   python main.py
   ```

   If `python` does not work, try:

   ```powershell
   py main.py
   ```

## How to use
1. Enter a task name.
2. Choose its priority.
3. Optionally enter a due date such as `2026-11-15`.
4. Click **Add task**.
5. Select a task to edit it, mark it complete, or delete it.
6. Use the search field and filters to find tasks.

Double-click a task row to toggle its completion status.

## Project structure
```text
CodSoft_ToDo_List/
├── main.py       # Application and user interface
├── tasks.json    # Created automatically when tasks are saved
└── README.md     # Setup and project guide
```

## Concepts demonstrated
- Python functions and classes
- Lists and dictionaries
- File handling with JSON
- Input validation and exception handling
- GUI programming with Tkinter
- Event-driven programming

## Notes
- `tasks.json` is created automatically in the same folder as `main.py`.
- Keep `tasks.json` in the same folder as `main.py` to retain saved tasks.
- This is a local desktop app; it does not require internet access.
