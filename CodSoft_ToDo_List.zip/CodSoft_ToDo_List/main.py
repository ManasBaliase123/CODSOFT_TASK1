"""CodSoft Internship - Task 1: To-Do List Application
A simple GUI task manager built with Python's Tkinter.
Tasks are saved locally in tasks.json.
"""
import json
import os
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(APP_DIR, "tasks.json")

BG = "#f4f7fb"
CARD = "#ffffff"
DARK = "#172033"
MUTED = "#64748b"
GREEN = "#16845b"
GREEN_DARK = "#106747"
RED = "#dc4545"
BORDER = "#e2e8f0"


class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("TaskFlow — To-Do List")
        self.root.geometry("980x690")
        self.root.minsize(780, 580)
        self.root.configure(bg=BG)
        self.tasks = self.load_tasks()
        self.selected_id = None
        self.filter_var = tk.StringVar(value="All tasks")
        self.search_var = tk.StringVar()
        self.title_var = tk.StringVar()
        self.priority_var = tk.StringVar(value="Medium")
        self.due_var = tk.StringVar()
        self.build_ui()
        self.refresh_tasks()

    def load_tasks(self):
        if not os.path.exists(DATA_FILE):
            return []
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, list) else []
        except (json.JSONDecodeError, OSError):
            messagebox.showwarning("Data file", "Could not read tasks.json. Starting with an empty list.")
            return []

    def save_tasks(self):
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(self.tasks, f, indent=2, ensure_ascii=False)

    def build_ui(self):
        header = tk.Frame(self.root, bg=GREEN, height=112)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="✓  TaskFlow", font=("Segoe UI", 25, "bold"),
                 bg=GREEN, fg="white").pack(anchor="w", padx=30, pady=(19, 0))
        tk.Label(header, text="Plan your day. Focus on what matters.",
                 font=("Segoe UI", 11), bg=GREEN, fg="#d8f5e7").pack(anchor="w", padx=34, pady=(2, 0))

        main = tk.Frame(self.root, bg=BG)
        main.pack(fill="both", expand=True, padx=25, pady=20)

        stats = tk.Frame(main, bg=BG)
        stats.pack(fill="x", pady=(0, 16))
        self.total_label = self.make_stat(stats, "TOTAL TASKS", "0")
        self.done_label = self.make_stat(stats, "COMPLETED", "0")
        self.pending_label = self.make_stat(stats, "PENDING", "0")

        content = tk.Frame(main, bg=BG)
        content.pack(fill="both", expand=True)

        left = tk.Frame(content, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
        left.pack(side="left", fill="y", padx=(0, 18))
        left.configure(width=280)
        left.pack_propagate(False)
        tk.Label(left, text="Add a task", font=("Segoe UI", 16, "bold"),
                 bg=CARD, fg=DARK).pack(anchor="w", padx=18, pady=(18, 14))

        self.field_label(left, "TASK NAME")
        title_entry = ttk.Entry(left, textvariable=self.title_var, font=("Segoe UI", 10))
        title_entry.pack(fill="x", padx=18, pady=(5, 13), ipady=7)
        title_entry.bind("<Return>", lambda _e: self.add_task())

        self.field_label(left, "PRIORITY")
        priority = ttk.Combobox(left, textvariable=self.priority_var,
                                values=["Low", "Medium", "High"], state="readonly")
        priority.pack(fill="x", padx=18, pady=(5, 13), ipady=4)

        self.field_label(left, "DUE DATE (OPTIONAL)")
        due_entry = ttk.Entry(left, textvariable=self.due_var, font=("Segoe UI", 10))
        due_entry.pack(fill="x", padx=18, pady=(5, 3), ipady=7)
        tk.Label(left, text="Format: YYYY-MM-DD", font=("Segoe UI", 8),
                 bg=CARD, fg=MUTED).pack(anchor="w", padx=19, pady=(0, 14))

        self.add_button = tk.Button(left, text="+  Add task", command=self.add_task,
                                    bg=GREEN, fg="white", activebackground=GREEN_DARK,
                                    activeforeground="white", relief="flat", bd=0,
                                    font=("Segoe UI", 10, "bold"), cursor="hand2", pady=10)
        self.add_button.pack(fill="x", padx=18, pady=(0, 8))
        tk.Button(left, text="Update selected task", command=self.update_task,
                  bg="#e6f5ed", fg=GREEN_DARK, activebackground="#d3eddf",
                  relief="flat", bd=0, font=("Segoe UI", 9, "bold"),
                  cursor="hand2", pady=9).pack(fill="x", padx=18, pady=(0, 8))
        tk.Button(left, text="Clear form", command=self.clear_form,
                  bg="#f1f5f9", fg=DARK, activebackground="#e2e8f0",
                  relief="flat", bd=0, font=("Segoe UI", 9),
                  cursor="hand2", pady=9).pack(fill="x", padx=18)

        right = tk.Frame(content, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
        right.pack(side="left", fill="both", expand=True)
        toolbar = tk.Frame(right, bg=CARD)
        toolbar.pack(fill="x", padx=18, pady=(17, 12))
        tk.Label(toolbar, text="Your tasks", font=("Segoe UI", 16, "bold"),
                 bg=CARD, fg=DARK).pack(side="left")
        self.search_entry = ttk.Entry(toolbar, textvariable=self.search_var, width=22)
        self.search_entry.pack(side="right", ipady=5)
        self.search_entry.insert(0, "")
        self.search_var.trace_add("write", lambda *_: self.refresh_tasks())

        filters = tk.Frame(right, bg=CARD)
        filters.pack(fill="x", padx=18, pady=(0, 10))
        for name in ("All tasks", "Pending", "Completed"):
            tk.Radiobutton(filters, text=name, variable=self.filter_var, value=name,
                           command=self.refresh_tasks, bg=CARD, fg=MUTED,
                           activebackground=CARD, selectcolor=CARD,
                           font=("Segoe UI", 9), cursor="hand2").pack(side="left", padx=(0, 12))

        columns = ("task", "priority", "due", "status")
        self.tree = ttk.Treeview(right, columns=columns, show="headings", selectmode="browse")
        self.tree.heading("task", text="TASK")
        self.tree.heading("priority", text="PRIORITY")
        self.tree.heading("due", text="DUE DATE")
        self.tree.heading("status", text="STATUS")
        self.tree.column("task", width=230, anchor="w")
        self.tree.column("priority", width=80, anchor="center")
        self.tree.column("due", width=100, anchor="center")
        self.tree.column("status", width=95, anchor="center")
        self.tree.pack(fill="both", expand=True, padx=18, pady=(0, 8))
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.tree.bind("<Double-1>", lambda _e: self.toggle_selected())

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview", background="white", fieldbackground="white",
                        foreground=DARK, rowheight=35, borderwidth=0,
                        font=("Segoe UI", 9))
        style.configure("Treeview.Heading", background="#f1f5f9", foreground="#475569",
                        font=("Segoe UI", 8, "bold"), relief="flat")
        style.map("Treeview", background=[("selected", "#d8f5e7")],
                  foreground=[("selected", DARK)])
        self.tree.tag_configure("completed", foreground="#94a3b8")
        self.tree.tag_configure("high", foreground="#c24141")

        actions = tk.Frame(right, bg=CARD)
        actions.pack(fill="x", padx=18, pady=(5, 16))
        self.action_button(actions, "✓  Mark complete / pending", self.toggle_selected, GREEN)
        self.action_button(actions, "Delete selected", self.delete_selected, RED)

        tk.Label(main, text="Tip: Double-click a task to change its completion status.",
                 bg=BG, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", pady=(10, 0))

    def make_stat(self, parent, label, value):
        card = tk.Frame(parent, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
        card.pack(side="left", fill="x", expand=True, padx=(0, 12))
        tk.Label(card, text=label, font=("Segoe UI", 8, "bold"),
                 bg=CARD, fg=MUTED).pack(anchor="w", padx=15, pady=(10, 1))
        number = tk.Label(card, text=value, font=("Segoe UI", 19, "bold"),
                          bg=CARD, fg=DARK)
        number.pack(anchor="w", padx=15, pady=(0, 8))
        return number

    def field_label(self, parent, text):
        tk.Label(parent, text=text, font=("Segoe UI", 8, "bold"),
                 bg=CARD, fg=MUTED).pack(anchor="w", padx=19)

    def action_button(self, parent, text, command, color):
        tk.Button(parent, text=text, command=command, bg=color, fg="white",
                  activebackground=color, activeforeground="white", relief="flat",
                  bd=0, font=("Segoe UI", 9, "bold"), cursor="hand2",
                  padx=10, pady=8).pack(side="left", padx=(0, 8))

    def add_task(self):
        title = self.title_var.get().strip()
        due = self.due_var.get().strip()
        if not title:
            messagebox.showwarning("Missing task", "Please enter a task name.")
            return
        if due:
            try:
                datetime.strptime(due, "%Y-%m-%d")
            except ValueError:
                messagebox.showwarning("Invalid date", "Use the date format YYYY-MM-DD.")
                return
        self.tasks.append({
            "id": str(datetime.now().timestamp()) + str(len(self.tasks)),
            "title": title, "priority": self.priority_var.get(),
            "due": due or "—", "completed": False
        })
        self.save_tasks()
        self.clear_form()
        self.refresh_tasks()

    def update_task(self):
        task = self.get_selected_task()
        if not task:
            messagebox.showinfo("Select a task", "Select a task from the list first.")
            return
        title = self.title_var.get().strip()
        due = self.due_var.get().strip()
        if not title:
            messagebox.showwarning("Missing task", "Please enter a task name.")
            return
        if due:
            try:
                datetime.strptime(due, "%Y-%m-%d")
            except ValueError:
                messagebox.showwarning("Invalid date", "Use the date format YYYY-MM-DD.")
                return
        task["title"] = title
        task["priority"] = self.priority_var.get()
        task["due"] = due or "—"
        self.save_tasks()
        self.refresh_tasks()
        self.clear_form()

    def clear_form(self):
        self.title_var.set("")
        self.priority_var.set("Medium")
        self.due_var.set("")
        self.selected_id = None
        self.tree.selection_remove(self.tree.selection())

    def get_selected_task(self):
        selection = self.tree.selection()
        if not selection:
            return None
        task_id = selection[0]
        return next((task for task in self.tasks if task["id"] == task_id), None)

    def on_select(self, _event=None):
        task = self.get_selected_task()
        if task:
            self.selected_id = task["id"]
            self.title_var.set(task["title"])
            self.priority_var.set(task.get("priority", "Medium"))
            self.due_var.set("" if task.get("due", "—") == "—" else task.get("due", ""))

    def toggle_selected(self):
        task = self.get_selected_task()
        if not task:
            messagebox.showinfo("Select a task", "Select a task first.")
            return
        task["completed"] = not task.get("completed", False)
        self.save_tasks()
        self.refresh_tasks()

    def delete_selected(self):
        task = self.get_selected_task()
        if not task:
            messagebox.showinfo("Select a task", "Select a task first.")
            return
        if messagebox.askyesno("Delete task", f"Delete '{task['title']}'?"):
            self.tasks = [t for t in self.tasks if t["id"] != task["id"]]
            self.save_tasks()
            self.clear_form()
            self.refresh_tasks()

    def refresh_tasks(self):
        if not hasattr(self, "tree"):
            return
        for item in self.tree.get_children():
            self.tree.delete(item)
        query = self.search_var.get().strip().lower()
        filter_value = self.filter_var.get()
        visible = []
        for task in self.tasks:
            completed = task.get("completed", False)
            if filter_value == "Pending" and completed:
                continue
            if filter_value == "Completed" and not completed:
                continue
            if query and query not in task.get("title", "").lower():
                continue
            visible.append(task)
        for task in visible:
            status = "Completed" if task.get("completed", False) else "Pending"
            tags = ("completed",) if task.get("completed", False) else (("high",) if task.get("priority") == "High" else ())
            self.tree.insert("", "end", iid=task["id"],
                             values=(task.get("title", ""), task.get("priority", "Medium"),
                                     task.get("due", "—"), status), tags=tags)
        total = len(self.tasks)
        done = sum(1 for task in self.tasks if task.get("completed", False))
        self.total_label.config(text=str(total))
        self.done_label.config(text=str(done))
        self.pending_label.config(text=str(total - done))


def main():
    root = tk.Tk()
    TodoApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
